# unity-gtk4-menu

Exports a GTK4 application's header bar menu to the Unity global menu and the
HUD.

GTK4 applications keep their menu in a `GtkMenuButton` in the header bar rather
than in a menu bar, so Unity's panel has nothing to show for them. GTK4 also
removed the module loading mechanism GTK3 has, which is how `appmenu-gtk-module`
reaches GTK3 applications, so there is no module to write.

This is an `LD_PRELOAD` library instead. It overwrites `realize` in the
`GtkWindow` class vtable, finds the header bar's menu model through public API,
and sets it as the application's menu bar before the window is realized. GTK4
then exports it over `org.gtk.Menus` and advertises it on the window, which is
all Unity needs - the transport was never missing, only a producer.

The same approach is already shipped in Ubuntu Unity by `gtk-nocsd`, which
disables client side decorations the same way, and this package follows its
packaging closely.

## Configuration

    gsettings set com.ubuntu-unity.gtk4-menu show-application-name false

A header bar menu has no name of its own. With this on, the entry is named
after the application, which repeats the name the panel shows beside it; with
it off, a neutral label is used. Default is on.

The snippet, `/usr/lib/environment.d/60-unity-gtk4-menu.conf`, preloads the
library by path, `/usr/$LIB/libunity-gtk4-menu.so.0`; the dynamic loader
expands `$LIB` to the multiarch directory (`lib/x86_64-linux-gnu` on amd64).
In environment.d syntax the `$` is written `$$`. Programs that run with
elevated privileges skip such an entry silently, so the library is installed
with mode 0644.

The user manager's value is replaced when an X session exports an `LD_PRELOAD`
of its own (from `~/.xsessionrc`, say): `95dbus_update-activation-env` imports
the session's value over it. So `/etc/X11/Xsession.d/52unity-gtk4-menu` puts
the library back at the front of such a value, after `51gtk-nocsd` has added
gtk-nocsd. It has to come first: with gtk-nocsd ahead of it, its
`g_module_symbol()` (below) is never reached. A copy of the library preloaded
from outside `/usr` (a build of one's own) is kept instead, if it exists. The
script does nothing when the session has no `LD_PRELOAD`, when the library is
turned off as below, or once the package is removed.

To disable the library entirely, shadow its environment snippet with an empty
file of the same name (the X session script honours it too):

    # everyone
    sudo touch /etc/environment.d/60-unity-gtk4-menu.conf
    # one user
    touch ~/.config/environment.d/60-unity-gtk4-menu.conf

## gjs and Python applications

A gjs or PyGObject application does not link GTK4; GObject Introspection
loads it when the script imports Gtk, long after the library's constructor has
looked for it. So the library also intercepts `g_module_symbol()`, through
which introspection resolves every GTK function before calling it, and hooks
GTK4 at the first `gtk_` or `adw_` lookup. The lookup itself is passed on
unchanged. gtk-nocsd, which Ubuntu Unity preloads as well, intercepts the same
function; see the next section.

The lookup is passed on to the next `g_module_symbol()` in load order, or,
when that search finds none, to libgmodule's own. Python opens its extension
modules without `RTLD_GLOBAL`, so in a PyGObject process libgmodule is not in
the global scope; up to 0.10 the lookup then failed, and without gtk-nocsd
preloaded (its opt-out) every PyGObject program stopped at its first import.
The library's `gtk_widget_action_set_enabled()` finds the real setter the same
way, falling back to libgtk-4's own; up to 0.10 a GTK4 plugin opened
`RTLD_LOCAL` by a program without GTK lost every class-action disable.

## Next to gtk-nocsd

Ubuntu Unity's session preloads both libraries, this one first
(`60-unity-gtk4-menu.conf` is applied after `50-gtk-nocsd.conf`, and each
prepends itself). Measured on 26.04 with gtk-nocsd 4.8 as Ubuntu builds it and
with gtk-nocsd's git head built by its own `make`, in both orders:

- This library first - the session's order: no crash, global menu for C, gjs
  and Python applications.
- gtk-nocsd first: no crash, but gjs and Python applications get no global
  menu. gtk-nocsd resolves the real `g_module_symbol()` through libgmodule's
  handle, so a library after it never sees the lookups. C applications are
  not affected.
- Up to 0.8 this library crashed most GTK4 applications, in either order,
  next to a gtk-nocsd built without `-Bsymbolic-functions` (its upstream
  `make`; Ubuntu's build flags add it, so Ubuntu's package did not show it).
  gtk-nocsd replaces `dlsym()`, and its answer for `g_module_symbol` was this
  library's own function, which then called itself. Since 0.9 the next
  definition is looked up with glibc's own `dlsym`.

Cases gtk-nocsd handles and this library does not:

- applications that load GTK4 through a raw `dlsym()` rather than
  `g_module_symbol()` - Gir.Core (.NET) - get no global menu;
- a statically linked GTK4 is not found, and the library does nothing.

GTK2 and GTK3 applications are outside this library's scope;
`appmenu-gtk-module` exports their menus.

## Which menu

A window often has several menu buttons. The library collects all of them and
exports the one that ranks first by:

1. shown - visible, and not inside a stack page, tab overview or similar
   part of the window that its container keeps hidden;
2. marked primary with `gtk_menu_button_set_primary()` - the button F10
   opens, which libadwaita applications set on their main menu;
3. the number of items naming `app.` or `win.` actions - the main menu is made
   of those, secondary menus usually of actions scoped to one widget;
4. tree order.

Changes to the menu are followed: when the application adds, removes or
relabels items (in the menu or in any of its sections and submenus), the
exported copy is edited in place, and only the changed items reach the panel.
An open panel menu stays open, except a submenu whose own item was relabelled.

A different menu shown later is followed too. When a menu button is mapped in
the window's header bar, or the followed menu's button is hidden or destroyed,
the window is looked at again, and a shown menu that ranks higher takes over:
papers shows its sidebar's main menu once a document opens. A hidden primary
menu is replaced only by another primary one or one with at least as many
items, so a collapsed sidebar does not hand the panel a document menu made of
actions it cannot reach. The copy is edited in place, as for a change.

## Actions the window does not export

The global menu can only activate what the application exports over D-Bus: the
application's actions (`app.`) and a `GtkApplicationWindow`'s own action map
(`win.`). Header bar menus may also name actions installed on a widget class
with `gtk_widget_class_install_action()` - yelp's "About Help" is one. Inside
the application the popover resolves them through the widget's action muxer;
over D-Bus nobody can, so they used to arrive greyed out.

For each such item the exported copy of the menu points at a stand-in added to
the window's action map, named `unity-gtk4-menu-<original name>`, which
activates the original from the menu button. Known limits:

- A stand-in follows the enabled state the application sets with
  `gtk_widget_action_set_enabled()` - GTK has no getter, so the library
  intercepts the setter and remembers each call on the widget. Calls GTK
  makes inside itself are not seen; they concern GTK's own widgets, which
  header bar menus do not use.
- Property actions (`gtk_widget_class_install_property_action()`) get a
  stateful stand-in that mirrors the property: a check item for a boolean,
  the selected radio item otherwise.
- Actions with a prefix other than `app.` or `win.` usually come from a group
  inserted on a sub-widget with `gtk_widget_insert_action_group()`, which
  public API cannot enumerate. They are left alone too.

The debug log names every action in each of these cases, so a new application
shows at once which one it hits.

## Testing without installing

    make
    LD_PRELOAD=./libunity-gtk4-menu.so.0 UNITY_GTK4_MENU_DEBUG=1 \
      UNITY_GTK4_MENU_LOG=/tmp/shim.log some-gtk4-application

`UNITY_GTK4_MENU_LABEL=app|generic` overrides the setting.
`UNITY_GTK4_MENU_FORCE=1` skips the check that the session is Unity.

`tests/classtest.c` is a minimal application with one item of each kind above,
plus a class action disabled at start and one that `win.toggle-hello` switches
on and off; every activation prints a line, so a test can drive it with
`gdbus call ... org.gtk.Actions.Activate` and read the result.
`tests/gjstest.js` does the same for gjs (`gjs -m tests/gjstest.js`).
