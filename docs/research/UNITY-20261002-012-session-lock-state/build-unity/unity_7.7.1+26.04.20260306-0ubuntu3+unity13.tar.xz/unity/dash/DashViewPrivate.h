/*
 * Copyright (C) 2011 Canonical Ltd
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Authored by: Marco Biscaro <marcobiscaro2112@gmail.com>
 */

#ifndef UNITY_DASH_VIEW_PRIVATE_H_
#define UNITY_DASH_VIEW_PRIVATE_H_

#include <string>
#include <map>

namespace unity
{
namespace dash
{
namespace impl
{

struct ScopeFilter
{
  std::string id;
  std::map<std::string, std::string> filters;
};

ScopeFilter parse_scope_uri(std::string const& uri);

} // namespace impl
} // namespace dash
} // namespace unity

#endif
